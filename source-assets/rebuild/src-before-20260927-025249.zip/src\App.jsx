import { lazy, Suspense, useEffect, useRef, useState } from 'react'
import About from './components/About'
import Acting from './components/Acting'
import Reel from './components/Reel'
import Directing from './components/Directing'
import Press from './components/Press'
import Contact from './components/Contact'
import useLenis from './lib/useLenis'
import WorldHeader from './components/world/WorldHeader'
import WorldHero from './components/world/WorldHero'
import BetweenFrames from './components/world/BetweenFrames'
import WorldCredits from './components/world/WorldCredits'
import { WorldMotionProvider } from './components/world/WorldMotion'
import './world.css'

const Music = lazy(() => import('./components/Music'))
const Business = lazy(() => import('./components/Business'))

function HeavySectionPlaceholder({ id, label }) {
  return (
    <section
      id={id}
      aria-label={label}
      aria-busy="true"
      className="min-h-[55vh] bg-obsidian border-t border-ivory/[0.05]"
    />
  )
}

/** Keep audio/3D libraries out of the opening scene's network/render budget. */
function DeferredSection({ id, label, children }) {
  const ref = useRef(null)
  const [nearby, setNearby] = useState(false)
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setNearby(true)
        observer.disconnect()
      }
    }, { rootMargin: '900px 0px' })
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])
  return (
    <div ref={ref} className="world-deferred">
      {nearby ? (
        <Suspense fallback={<HeavySectionPlaceholder id={id} label={label} />}>{children}</Suspense>
      ) : <HeavySectionPlaceholder id={id} label={label} />}
    </div>
  )
}

function App() {
  useLenis()
  useEffect(() => {
    // Existing deep links still open at the right archive chapter.
    if (window.location.hash) {
      let id
      try { id = decodeURIComponent(window.location.hash.slice(1)) } catch { return }
      const target = document.getElementById(id)
      if (target) target.scrollIntoView({ behavior: 'instant' })
    }
  }, [])

  return (
    <WorldMotionProvider>
        <WorldHeader />
        <main id="main" tabIndex={-1}>
          <WorldHero />
          <BetweenFrames />
          <WorldCredits />
          <About />
          <Acting />
          <Reel />
          <DeferredSection id="music" label="Music"><Music /></DeferredSection>
          <DeferredSection id="business" label="MOSS Algorithm"><Business /></DeferredSection>
          <Directing />
          <Press />
          <Contact />
        </main>
    </WorldMotionProvider>
  )
}

export default App
